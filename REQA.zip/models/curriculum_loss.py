import torch.nn as nn
import torch
import torch.nn.functional as F


class CurriculumLoss1(nn.Module):
    def __init__(self):
        super(CurriculumLoss1, self).__init__()
        self.t = 3
        self.criterion = nn.L1Loss(reduction='none').cuda()

    def forward(self, scores, label):
        losses1 = [self.criterion(score, label) for score in scores]
        li = torch.tensor([[5.0], [2.5], [0.0]], dtype=torch.float64).cuda()
        losses2 = torch.stack(losses1)
        losses3 = losses2 - li
        final_losses = F.relu(losses3)
        loss = (1.5 * final_losses[0] + final_losses[1] + 0.5 * final_losses[2]) / 3
        loss = torch.mean(loss)
        return loss


class CurriculumLoss2(nn.Module):
    def __init__(self):
        super(CurriculumLoss2, self).__init__()
        self.t = 3
        self.criterion = nn.L1Loss(reduction='none').cuda()

    def forward(self, scores, label):
        losses1 = [self.criterion(score, label) for score in scores]
        li = torch.tensor([[5.0], [2.5], [0.0]], dtype=torch.float64).cuda()
        losses2 = torch.stack(losses1)
        losses3 = losses2 - li
        final_losses = F.relu(losses3)
        loss = (0.5 * final_losses[0] + 1.5 * final_losses[1] + final_losses[2]) / 3
        loss = torch.mean(loss)
        return loss


class CurriculumLoss3(nn.Module):
    def __init__(self):
        super(CurriculumLoss3, self).__init__()
        self.t = 3
        self.criterion = nn.L1Loss(reduction='none').cuda()

    def forward(self, scores, label):
        losses1 = [self.criterion(score, label) for score in scores]
        li = torch.tensor([[5.0], [2.5], [0.0]], dtype=torch.float64).cuda()
        losses2 = torch.stack(losses1)
        losses3 = losses2 - li
        final_losses = F.relu(losses3)
        loss = (0.5 * final_losses[0] + final_losses[1] + 1.5 * final_losses[2]) / 3
        loss = torch.mean(loss)
        return loss
