import torch
import torch.nn as nn


class FeedbackModule(nn.Module):
    def __init__(self, convlstmstacks, t, in_channels, map_pixels, lda_out_channels):
        super(FeedbackModule, self).__init__()
        self.cells = nn.ModuleList(convlstmstacks)
        self.t = t
        self.pool = nn.AvgPool2d(7, stride=7)
        self.fc = nn.Linear(in_channels*map_pixels, lda_out_channels)
        nn.init.kaiming_normal_(self.fc.weight.data)

    def forward(self, x):
        end_xts = []
        for T in range(self.t):
            x_t = x
            for cell in self.cells:
                x_t = cell(x_t)  # .forward(x_t)
            x_t = self.pool(x_t).view(x.size(0), -1)
            x_t = self.fc(x_t)
            end_xts.append(x_t)

        for cell in self.cells:
            if(hasattr(cell, 'reset_state')):
                cell.reset_state()

        return end_xts

