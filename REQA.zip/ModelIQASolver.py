import torch
import random
import numpy as np
import data_loader
from scipy import stats
from models.REQA import REQANet
from models.RankLoss import RankLoss1
from models.curriculum_loss import CurriculumLoss1, CurriculumLoss2, CurriculumLoss3


def setup():
    model = REQANet()
    model.cuda()
    return model


def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


class ModelIQASolver(object):
    """Solver for training and testing"""
    def __init__(self, args, path, train_idx, test_idx, round_index):
        self.epochs = args.epochs
        self.test_patch_num = args.test_patch_num

        self.model = setup()
        self.model.train(True)

        self.coarse_loss = RankLoss1().cuda()
        self.fine_loss = CurriculumLoss3().cuda()
        self.rank_gradient_weight = args.rank_gradient_weight
        backbone_params = list(map(id, self.model.res.parameters()))
        self.other_params = filter(lambda p: id(p) not in backbone_params, self.model.parameters())
        self.lr = args.lr
        self.lrratio = args.lr_ratio
        self.weight_decay = args.weight_decay
        paras = [{'params': self.other_params, 'lr': self.lr * self.lrratio},
                 {'params': self.model.res.parameters(), 'lr': self.lr}
                 ]
        self.solver = torch.optim.Adam(paras, weight_decay=self.weight_decay)

        train_loader = data_loader.DataLoader(args.dataset, path, train_idx, args.patch_size, args.train_patch_num, batch_size=args.batch_size, istrain=True)
        test_loader = data_loader.DataLoader(args.dataset, path, test_idx, args.patch_size, args.test_patch_num, istrain=False)
        self.train_data = train_loader.get_data()
        self.test_data = test_loader.get_data()

        self.output_dir = args.output_dir
        self.seed = args.seed
        self.round_index = round_index

    def train(self):
        """Training"""
        set_seed(self.seed)
        best_srcc = 0.0
        best_plcc = 0.0
        print('Epoch\tTrain_Loss\tTrain_SRCC\tTest_SRCC\tTest_PLCC')
        for t in range(self.epochs):
            epoch_loss1 = []
            epoch_loss2 = []
            pred_score = []
            pred_scores = []
            gt_scores = []
            best_preds = []

            for img, label in self.train_data:
                img = torch.tensor(img.cuda())
                label = torch.tensor(label.cuda())

                self.solver.zero_grad()

                pred, preds = self.model(img)
                pred_score = pred_score + pred.cpu().tolist()
                pred_scores = pred_scores + preds[2].cpu().tolist()
                gt_scores = gt_scores + label.cpu().tolist()

                loss1 = self.coarse_loss(pred, label.float().detach())
                epoch_loss1.append(loss1.item())
                loss2 = self.fine_loss(preds, label.float().detach())
                epoch_loss2.append(loss2.item())
                loss2 = (1 - self.rank_gradient_weight) * loss2 + self.rank_gradient_weight * loss1
                loss2.backward()
                self.solver.step()
            train_srcc, _ = stats.spearmanr(pred_scores, gt_scores)

            test_srcc, test_plcc = self.test(self.test_data)
            if test_srcc > best_srcc:
                best_srcc = test_srcc
                best_preds = pred_scores
            if test_plcc > best_plcc:
                best_plcc = test_plcc
            print('%d\t%4.3f\t\t%4.3f\t\t%4.4f\t\t%4.4f\t\t%4.4f' %
                  (t + 1, sum(epoch_loss1) / len(epoch_loss1), sum(epoch_loss2) / max(1, len(epoch_loss2)), train_srcc, test_srcc, test_plcc))

            # Update optimizer
            lr = self.lr / pow(10, (t // 10))
            if t > 10:
                self.lrratio = 1
            self.paras = [{'params': self.other_params, 'lr': lr * self.lrratio},
                          {'params': self.model.res.parameters(), 'lr': self.lr}
                          ]
            self.solver = torch.optim.Adam(self.paras, weight_decay=self.weight_decay)

            if t == 10:
                self.fine_loss = CurriculumLoss3().cuda()

            if t == 20:
                self.fine_loss = CurriculumLoss3().cuda()

        print('Best test SRCC %f, PLCC %f' % (best_srcc, best_plcc))
        print('Prediction Scores:')
        print(best_preds)
        print('Ground Truth:')
        print(gt_scores)

        return best_srcc, best_plcc

    def test(self, data):
        """Testing"""
        self.model.train(False)
        pred_scores = []
        gt_scores = []

        for img, label in data:
            img = torch.tensor(img.cuda())
            label = torch.tensor(label.cuda())
            pred, preds = self.model(img)

            pred_scores.append(float(preds[2].item()))
            gt_scores = gt_scores + label.cpu().tolist()

        pred_scores = np.mean(np.reshape(np.array(pred_scores), (-1, self.test_patch_num)), axis=1)
        gt_scores = np.mean(np.reshape(np.array(gt_scores), (-1, self.test_patch_num)), axis=1)
        test_srcc, _ = stats.spearmanr(pred_scores, gt_scores)
        test_plcc, _ = stats.pearsonr(pred_scores, gt_scores)

        self.model.train(True)
        return test_srcc, test_plcc