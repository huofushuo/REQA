import torch
import torch.nn as nn
from models.convlstmcell import ConvLSTMCell


class ConvLSTMStack(nn.Module):

    def __init__(self, input_size, output_size, x_kernel_size=3, h_kernel_size=3, stride=1, conv_num_per_cell=1):
        super(ConvLSTMStack, self).__init__()
        operations = []
        self.cells = nn.ModuleList()
        first_cell = ConvLSTMCell(input_size, output_size, x_kernel_size, h_kernel_size, stride, conv_num_per_cell)
        self.cells.append(first_cell)
        operations.append(first_cell)
        self.stack = nn.Sequential(*operations)

    def reset_state(self):
        for cell in self.cells:
            cell.reset_state()

    def forward(self, x):
        return self.stack(x)

