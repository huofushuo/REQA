import torch.nn as nn
import torch
import torch.nn.functional as F


class RankLoss1(nn.Module):
    def __init__(self):
        super(RankLoss1, self).__init__()

    def forward(self, scores, label):
        batch_size = scores.size()[0]
        scores = scores.expand(batch_size, batch_size)
        scores_trans = torch.transpose(scores, 0, 1)
        label = label.expand(batch_size, batch_size)
        label_trans = torch.transpose(label, 0, 1)
        scores_dif = scores - scores_trans
        label_dif = label - label_trans
        mul = -1.0 * torch.mul(scores_dif, label_dif)
        stable = 0.0001
        scores_dif_abs = torch.abs(scores_dif)+stable
        label_dif_abs = torch.abs(label_dif)+stable
        loss = F.relu(mul/scores_dif_abs) + F.relu(mul/label_dif_abs)
        loss = torch.mean(loss)
        return loss


class RankLoss2(nn.Module):
    def __init__(self):
        super(RankLoss2, self).__init__()

    def forward(self, scores, label):
        batch_size = scores.size()[0] 
        scores = scores.expand(batch_size, batch_size)
        scores_trans = torch.transpose(scores, 0, 1)
        label = label.expand(batch_size, batch_size)
        label_trans = torch.transpose(label, 0, 1)
        scores_dif = scores - scores_trans
        label_dif = label - label_trans
        mul = -1.0 * torch.mul(scores_dif, label_dif)
        stable = 0.0001
        label_dif_abs = torch.abs(label_dif)
        loss = F.relu(mul/(label_dif_abs+stable))
        loss = torch.mul(loss, (label_dif_abs+1))
        loss = torch.mean(loss)
        return loss
