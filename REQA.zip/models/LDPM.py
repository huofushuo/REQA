import torch
import torch.nn as nn
from models.convlstmstack import ConvLSTMStack
from models.feedbackmodule import FeedbackModule


class FeedbackNet(nn.Module):
    def __init__(self, res):
        super(FeedbackNet, self).__init__()
        self.res = res
        self.lda_out_dimension = 32

        stack1 = [
            ConvLSTMStack(256, 16, 1, 1, 1, 1)
        ]
        stack2 = [
            ConvLSTMStack(512, 32, 1, 1, 1, 1)
        ]
        stack3 = [
            ConvLSTMStack(1024, 64, 1, 1, 1, 1)
        ]
        self.lda1_feedback = FeedbackModule(stack1, 4, 16, 64, self.lda_out_dimension)
        self.lda2_feedback = FeedbackModule(stack2, 4, 32, 16, self.lda_out_dimension)
        self.lda3_feedback = FeedbackModule(stack3, 4, 64, 4, self.lda_out_dimension)

    def forward(self, img):
        res_out = self.res(img)
        lda_1_all = self.lda1_feedback(res_out['feature1'])
        lda_2_all = self.lda2_feedback(res_out['feature2'])
        lda_3_all = self.lda3_feedback(res_out['feature3'])

        return lda_1_all, lda_2_all, lda_3_all
