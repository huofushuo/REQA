import os
import argparse
import random
import numpy as np
from ModelIQASolver import ModelIQASolver
import torch
import warnings
warnings.filterwarnings("ignore")

os.environ['CUDA_VISIBLE_DEVICES'] = '0'


def set_seed(args):
    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)


def main(config):
    folder_path = {
        'livec': r'./data/CLIVE/',
        'koniq-10k': r'./data/koniq-10k/',
        'bid': r'./data/BID/',
    }

    img_num = {
        'livec': list(range(0, 1162)),
        'koniq-10k': list(range(0, 10073)),
        'bid': list(range(0, 586)),
    }
    sel_num = img_num[config.dataset]

    srcc_all = np.zeros(config.train_test_num, dtype=np.float)
    plcc_all = np.zeros(config.train_test_num, dtype=np.float)

    print('Training and testing on %s dataset for %d rounds...' % (config.dataset, config.train_test_num))
    for i in range(config.train_test_num):
        print('Round %d' % (i + 1))
        # Randomly select 80% images for training and the rest for testing
        random.shuffle(sel_num)
        train_index = sel_num[0:int(round(0.8 * len(sel_num)))]
        test_index = sel_num[int(round(0.8 * len(sel_num))):len(sel_num)]
        print(train_index)
        print(test_index)

        solver = ModelIQASolver(config, folder_path[config.dataset], train_index, test_index, i + 1)
        srcc_all[i], plcc_all[i] = solver.train()

    srcc_med = np.median(srcc_all)
    plcc_med = np.median(plcc_all)

    print('Testing median SRCC %4.4f,\tmedian PLCC %4.4f' % (srcc_med, plcc_med))
    print('Testing SROCC and PLCC for %d Rounds:' % config.train_test_num)
    print(srcc_all)
    print(plcc_all)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()

    # parser.add_argument('--mode', dest='mode', type=str, default='train', help='train|test')
    # train_test_set
    parser.add_argument('--dataset', dest='dataset', type=str, default='bid',
                        help='Support datasets: livec|koniq-10k|bid|live|csiq|tid2013')
    parser.add_argument('--train_test_num', dest='train_test_num', type=int, default=30, help='Train-test times')
    parser.add_argument('--batch_size', dest='batch_size', type=int, default=16, help='Batch size')
    parser.add_argument('--epochs', dest='epochs', type=int, default=30, help='Epochs for training')

    # train_test_import_set.
    parser.add_argument('--train_patch_num', dest='train_patch_num', type=int, default=1,
                        help='Number of sample patches from training image')
    parser.add_argument('--test_patch_num', dest='test_patch_num', type=int, default=25,
                        help='Number of sample patches from testing image')
    parser.add_argument('--patch_size', dest='patch_size', type=int, default=224,
                        help='Crop size for training & testing image patches')
    parser.add_argument("--img_size", default=224, type=int,
                        help="Resolution size")

    # training_set
    parser.add_argument('--lr', dest='lr', type=float, default=2e-5, help='Learning rate')
    parser.add_argument('--weight_decay', dest='weight_decay', type=float, default=5e-4, help='Weight decay')
    parser.add_argument('--lr_ratio', dest='lr_ratio', type=int, default=10, help='Learning rate ratio for model')
    parser.add_argument('--rank_gradient_weight', type=float, default=0.25,
                        help="rank_gradient_weight")

    # output_set
    parser.add_argument("--output_dir", default="output", type=str,
                        help="The output directory where checkpoints will be written.")

    parser.add_argument('--seed', type=int, default=42,
                        help="random seed for initialization")

    args = parser.parse_args()
    set_seed(args)
    main(args)
